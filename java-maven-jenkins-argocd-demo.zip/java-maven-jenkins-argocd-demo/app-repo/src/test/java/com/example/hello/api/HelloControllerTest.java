package com.example.hello.api;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

public class HelloControllerTest {

  @Test
  void simpleUnitTest() {
    HelloController controller = new HelloController();
    assertThat(controller.hello().get("message")).contains("Hello");
  }
}
