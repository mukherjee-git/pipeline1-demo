package com.example.hello.api;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class HelloControllerIT {

  @LocalServerPort
  int port;

  @Test
  void functionalTest_helloEndpoint() {
    given()
      .baseUri("http://localhost")
      .port(port)
    .when()
      .get("/api/hello")
    .then()
      .statusCode(200)
      .body("message", equalTo("Hello from Jenkins + ArgoCD demo!"));
  }
}
